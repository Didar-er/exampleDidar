package calc

func AddInts(a, b int) int {
	return a + b
}
